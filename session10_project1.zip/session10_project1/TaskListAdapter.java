package com.example.project1todolist.androidproject1todolist;

/**
 * Created by trident on 2/6/16.
 */
public class TaskListAdapter {

    String tittle;

    public TaskListAdapter(String tittle) {
        this.tittle = tittle;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    @Override
    public String toString() {
        return "TaskListAdapter{" +
                "tittle='" + tittle + '\'' +
                '}';
    }
}
